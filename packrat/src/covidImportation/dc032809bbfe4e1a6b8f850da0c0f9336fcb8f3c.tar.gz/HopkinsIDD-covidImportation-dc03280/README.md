# covidImportation



## Installation

Required package:
```{r}
devtools::install_github("HopkinsIDD/globaltoolboxlite")
```

Current version:
```{r}
devtools::install_github("HopkinsIDD/covidImportation")
```

Stable frozen version:
```{r}
devtools::install_github("HopkinsIDD/covidImportation", ref="v1.5")
```




## Data Sources

https://github.com/datasets/airport-codes. csv with all airports that includes Lat/Long.

